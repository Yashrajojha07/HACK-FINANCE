import { metrics, activities, agents, tasks, taskResults, financialReports } from "@shared/schema";
import type { 
  Metric, Activity, Agent, Task, TaskResult, FinancialReport,
  InsertMetric, InsertActivity, InsertAgent, InsertTask, InsertTaskResult, InsertFinancialReport 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte } from "drizzle-orm";

export interface IStorage {
  // Existing interfaces remain unchanged
  getMetrics(): Promise<Metric[]>;
  createMetric(metric: InsertMetric): Promise<Metric>;
  getActivities(): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getAgents(): Promise<Agent[]>;
  getAgent(id: number): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgentStatus(id: number, status: string): Promise<Agent>;
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskStatus(id: number, status: string): Promise<Task>;
  getTaskResult(taskId: number): Promise<TaskResult | undefined>;
  createTaskResult(result: InsertTaskResult): Promise<TaskResult>;

  // New interfaces for scheduled tasks
  getScheduledTasks(): Promise<Task[]>;
  getPendingScheduledTasks(): Promise<Task[]>;

  // New interfaces for financial reports
  getFinancialReports(): Promise<FinancialReport[]>;
  getFinancialReport(id: number): Promise<FinancialReport | undefined>;
  createFinancialReport(report: InsertFinancialReport): Promise<FinancialReport>;
  updateFinancialReportStatus(id: number, status: string): Promise<FinancialReport>;
}

export class DatabaseStorage implements IStorage {
  // Existing methods remain unchanged
  async getMetrics(): Promise<Metric[]> {
    return await db.select().from(metrics);
  }

  async createMetric(metric: InsertMetric): Promise<Metric> {
    const [newMetric] = await db.insert(metrics).values(metric).returning();
    return newMetric;
  }

  async getActivities(): Promise<Activity[]> {
    return await db.select().from(activities).orderBy(activities.timestamp);
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  async getAgents(): Promise<Agent[]> {
    return await db.select().from(agents);
  }

  async getAgent(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }

  async createAgent(agent: InsertAgent): Promise<Agent> {
    const [newAgent] = await db.insert(agents).values(agent).returning();
    return newAgent;
  }

  async updateAgentStatus(id: number, status: string): Promise<Agent> {
    const [updatedAgent] = await db
      .update(agents)
      .set({ status })
      .where(eq(agents.id, id))
      .returning();
    return updatedAgent;
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).orderBy(desc(tasks.created_at));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTaskStatus(id: number, status: string): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ 
        status,
        completed_at: status === 'completed' ? new Date() : null 
      })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }

  // Task Results
  async getTaskResult(taskId: number): Promise<TaskResult | undefined> {
    const [result] = await db
      .select()
      .from(taskResults)
      .where(eq(taskResults.task_id, taskId));
    return result;
  }

  async createTaskResult(result: InsertTaskResult): Promise<TaskResult> {
    const [newResult] = await db
      .insert(taskResults)
      .values(result)
      .returning();
    return newResult;
  }

  // New methods for scheduled tasks
  async getScheduledTasks(): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.status, 'scheduled'),
          gte(tasks.schedule_time, new Date())
        )
      )
      .orderBy(tasks.schedule_time);
  }

  async getPendingScheduledTasks(): Promise<Task[]> {
    const now = new Date();
    return await db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.status, 'scheduled'),
          gte(tasks.schedule_time, now)
        )
      )
      .orderBy(tasks.schedule_time);
  }

  // New methods for financial reports
  async getFinancialReports(): Promise<FinancialReport[]> {
    return await db
      .select()
      .from(financialReports)
      .orderBy(desc(financialReports.created_at));
  }

  async getFinancialReport(id: number): Promise<FinancialReport | undefined> {
    const [report] = await db
      .select()
      .from(financialReports)
      .where(eq(financialReports.id, id));
    return report;
  }

  async createFinancialReport(report: InsertFinancialReport): Promise<FinancialReport> {
    const [newReport] = await db
      .insert(financialReports)
      .values(report)
      .returning();
    return newReport;
  }

  async updateFinancialReportStatus(id: number, status: string): Promise<FinancialReport> {
    const [updatedReport] = await db
      .update(financialReports)
      .set({ 
        status,
        updated_at: new Date()
      })
      .where(eq(financialReports.id, id))
      .returning();
    return updatedReport;
  }
}

export const storage = new DatabaseStorage();