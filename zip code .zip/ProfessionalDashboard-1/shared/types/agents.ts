export interface AgentResponse {
  message: string;
  timestamp: string;
  status: 'success' | 'error' | 'warning';
  data?: any;
}

export interface AuditAgent {
  analyzeFinancials: (data: {
    period: string;
    statements: {
      type: 'income' | 'balance' | 'cashflow';
      data: Record<string, number>;
    }[];
  }) => Promise<AgentResponse>;
}

export interface GSTAgent {
  validateFiling: (data: {
    quarter: string;
    transactions: {
      date: string;
      amount: number;
      type: 'input' | 'output';
      category: string;
    }[];
  }) => Promise<AgentResponse>;
}

export interface TradeAgent {
  analyzePatterns: (data: {
    timeframe: string;
    trades: {
      timestamp: string;
      symbol: string;
      type: 'buy' | 'sell';
      price: number;
      quantity: number;
    }[];
  }) => Promise<AgentResponse>;
}

export interface FraudAgent {
  analyzeTransactions: (data: {
    timeframe: string;
    transactions: {
      timestamp: string;
      amount: number;
      risk_score: number;
    }[];
  }) => Promise<AgentResponse>;
}

export interface ExcelAgent {
  analyzeWorkbook: (data: {
    fileType: string;
    analysis?: {
      type: string;
      metrics?: string[];
      depth?: string;
    };
    validation?: {
      sheets: string[];
      rules: string[];
    };
    optimization?: {
      target: string;
      areas: string[];
    };
  }) => Promise<AgentResponse>;
}