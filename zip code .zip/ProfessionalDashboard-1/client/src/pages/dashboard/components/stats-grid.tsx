import { MetricCard } from "./metric-card";
import { Skeleton } from "@/components/ui/skeleton";
import type { Metric } from "@shared/schema";

interface StatsGridProps {
  metrics?: Metric[];
  isLoading: boolean;
}

export function StatsGrid({ metrics, isLoading }: StatsGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-[120px]" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics?.map((metric) => (
        <MetricCard key={metric.id} metric={metric} />
      ))}
    </div>
  );
}
