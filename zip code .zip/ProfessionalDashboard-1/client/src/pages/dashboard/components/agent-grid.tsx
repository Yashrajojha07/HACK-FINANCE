import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { Agent } from "@shared/schema";

interface AgentGridProps {
  agents?: Agent[];
  isLoading: boolean;
}

function getStatusColor(status: string) {
  switch (status) {
    case 'available':
      return 'bg-green-100 text-green-800';
    case 'busy':
      return 'bg-yellow-100 text-yellow-800';
    case 'offline':
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

function getAgentColor(type: string) {
  switch (type) {
    case 'audit':
      return 'bg-blue-50 border-blue-200';
    case 'gst':
      return 'bg-green-50 border-green-200';
    case 'fraud_detection':
      return 'bg-red-50 border-red-200';
    case 'trade_analytics':
      return 'bg-purple-50 border-purple-200';
    case 'excel_evaluation':
      return 'bg-orange-50 border-orange-200';
    default:
      return 'bg-gray-50 border-gray-200';
  }
}

export function AgentGrid({ agents, isLoading }: AgentGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Skeleton key={i} className="h-[200px]" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {agents?.map((agent) => (
        <Card 
          key={agent.id} 
          className={`p-6 border-2 transition-all hover:shadow-lg ${getAgentColor(agent.type)}`}
        >
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-lg font-semibold">{agent.name}</h3>
            <Badge className={getStatusColor(agent.status)}>{agent.status}</Badge>
          </div>
          <p className="text-sm text-gray-600 mb-4">{agent.description}</p>
          <div className="space-y-2">
            {agent.capabilities.map((capability, index) => (
              <Badge key={index} variant="outline" className="mr-2">
                {capability}
              </Badge>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}