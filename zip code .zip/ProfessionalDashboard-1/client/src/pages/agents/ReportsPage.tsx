import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { FinancialReport } from "@shared/schema";

export default function ReportsPage() {
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: reports, isLoading } = useQuery<FinancialReport[]>({
    queryKey: ["/api/reports"],
  });

  const handleCreateReport = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    try {
      const response = await fetch("/api/reports", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: formData.get("title"),
          type: formData.get("type"),
          period: formData.get("period"),
          status: "draft",
          data: {},
          metadata: {
            created: new Date().toISOString(),
            department: formData.get("department"),
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to create report");

      toast({
        title: "Success",
        description: "Report created successfully",
      });

      setIsCreateDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create report",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <h1 className="text-2xl font-bold mb-6">Financial Reports</h1>
        <div className="grid gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Financial Reports</h1>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>Create New Report</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Report</DialogTitle>
              <DialogDescription>
                Fill in the details for the new financial report.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateReport} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="title">Title</label>
                <Input id="title" name="title" required />
              </div>
              <div className="space-y-2">
                <label htmlFor="type">Type</label>
                <Select name="type" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="balance_sheet">Balance Sheet</SelectItem>
                    <SelectItem value="income_statement">Income Statement</SelectItem>
                    <SelectItem value="cash_flow">Cash Flow</SelectItem>
                    <SelectItem value="audit_report">Audit Report</SelectItem>
                    <SelectItem value="gst_report">GST Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label htmlFor="period">Period</label>
                <Input id="period" name="period" placeholder="e.g., Q1-2024" required />
              </div>
              <div className="space-y-2">
                <label htmlFor="department">Department</label>
                <Input id="department" name="department" placeholder="e.g., Finance" required />
              </div>
              <Button type="submit" className="w-full">
                Create Report
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {reports?.map((report) => (
          <Card key={report.id} className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-semibold">{report.title}</h3>
                <p className="text-sm text-muted-foreground">
                  Period: {report.period}
                </p>
              </div>
              <Badge variant={report.status === "published" ? "default" : "secondary"}>
                {report.status}
              </Badge>
            </div>
            <div className="flex gap-2">
              <Badge variant="outline">{report.type}</Badge>
              {report.metadata?.department && (
                <Badge variant="outline">{report.metadata.department}</Badge>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
