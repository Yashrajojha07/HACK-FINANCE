import { AgentCard } from "@/components/agents/AgentCard";
import { mockAgentService } from "@/lib/mockAgentService";
import { mockRecommendationService, TaskRecommendation } from "@/lib/mockRecommendationService";
import { RecommendationCard } from "@/components/agents/RecommendationCard";
import { Card } from "@/components/ui/card";
import { FileUpload } from "@/components/ui/file-upload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";

// Sample data for visualizations
const priceData = [
  { date: "2024-01-01", actual: 185.50, predicted: 184.20 },
  { date: "2024-01-08", actual: 188.75, predicted: 187.90 },
  { date: "2024-01-15", actual: 192.30, predicted: 191.50 },
  { date: "2024-01-22", actual: 190.80, predicted: 193.20 },
  { date: "2024-01-29", actual: 194.25, predicted: 195.10 }
];

const volumeData = [
  { date: "2024-01-01", volume: 1200 },
  { date: "2024-01-08", volume: 1500 },
  { date: "2024-01-15", volume: 1800 },
  { date: "2024-01-22", volume: 1400 },
  { date: "2024-01-29", volume: 1600 }
];

export default function TradePage() {
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<TaskRecommendation[]>([]);
  const [activeTab, setActiveTab] = useState("patterns");

  const handleFileUpload = (files: File[]) => {
    console.log("Files uploaded:", files);
    setUploadedFiles(files.map(f => f.name));
  };

  const handleAcceptRecommendation = (recommendation: TaskRecommendation) => {
    console.log("Accepted recommendation:", recommendation);
    // TODO: Implement recommendation action
  };

  // Fetch recommendations whenever context changes
  useEffect(() => {
    const fetchRecommendations = async () => {
      const newRecommendations = await mockRecommendationService.getRecommendations({
        agentType: 'trade',
        currentTask: activeTab,
        uploadedFiles
      });
      setRecommendations(newRecommendations);
    };

    fetchRecommendations();
  }, [activeTab, uploadedFiles]);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Trade Analytics</h1>

      {/* Recommendations Section */}
      {recommendations.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Recommended Actions</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {recommendations.map((recommendation) => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                onAccept={handleAcceptRecommendation}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Upload Trading Data</h2>
        <FileUpload 
          accept=".csv,.xlsx,.json"
          multiple
          onFilesSelected={handleFileUpload}
          className="max-w-2xl"
        />
      </div>

      <Tabs defaultValue="patterns" className="mb-6" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="patterns">Pattern Analysis</TabsTrigger>
          <TabsTrigger value="prediction">Price Prediction</TabsTrigger>
          <TabsTrigger value="volume">Volume Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="patterns">
          <div className="grid gap-6 md:grid-cols-2">
            <AgentCard
              title="Trade Pattern Analysis"
              description="Analyze trading patterns and get market insights"
              agentType="trade"
              onAnalyze={() => mockAgentService.tradeAgent({
                timeframe: "1M",
                trades: [
                  {
                    timestamp: "2024-02-01T10:00:00Z",
                    symbol: "AAPL",
                    type: "buy",
                    price: 185.50,
                    quantity: 100
                  },
                  {
                    timestamp: "2024-02-10T15:30:00Z",
                    symbol: "MSFT",
                    type: "sell",
                    price: 420.25,
                    quantity: 50
                  }
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Price Movement Pattern</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={priceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual Price" />
                      <Line type="monotone" dataKey="predicted" stroke="#82ca9d" name="Predicted Price" strokeDasharray="5 5" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>

            <AgentCard
              title="Volume Analysis"
              description="Analyze trading volume patterns"
              agentType="trade"
              onAnalyze={() => mockAgentService.tradeAgent({
                timeframe: "1M",
                trades: [
                  {
                    timestamp: "2024-02-01T10:00:00Z",
                    symbol: "AAPL",
                    type: "volume",
                    quantity: 1500
                  }
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Trading Volume Trend</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={volumeData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Area type="monotone" dataKey="volume" fill="#8884d8" stroke="#8884d8" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>
          </div>
        </TabsContent>

        <TabsContent value="prediction">
          <AgentCard
            title="Price Prediction"
            description="Get AI-powered price predictions for selected securities"
            agentType="trade"
            onAnalyze={() => mockAgentService.tradeAgent({
              timeframe: "1M",
              trades: [
                {
                  timestamp: "2024-02-01T10:00:00Z",
                  symbol: "AAPL",
                  type: "prediction",
                  price: 185.50
                }
              ]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Upload historical price data and get AI-powered predictions
                for future price movements.
              </p>
            </Card>
          </AgentCard>
        </TabsContent>

        <TabsContent value="volume">
          <AgentCard
            title="Volume Trend Analysis"
            description="Analyze trading volume patterns and liquidity"
            agentType="trade"
            onAnalyze={() => mockAgentService.tradeAgent({
              timeframe: "1M",
              trades: [
                {
                  timestamp: "2024-02-01T10:00:00Z",
                  symbol: "AAPL",
                  type: "volume",
                  quantity: 1500
                }
              ]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Analyze trading volume trends and identify potential
                market opportunities based on liquidity patterns.
              </p>
            </Card>
          </AgentCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}