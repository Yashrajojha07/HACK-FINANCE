import { AgentCard } from "@/components/agents/AgentCard";
import { mockAgentService } from "@/lib/mockAgentService";
import { mockRecommendationService, TaskRecommendation } from "@/lib/mockRecommendationService";
import { RecommendationCard } from "@/components/agents/RecommendationCard";
import { Card } from "@/components/ui/card";
import { FileUpload } from "@/components/ui/file-upload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

// Sample data for visualizations
const monthlyGST = [
  { month: "Jan", input: 15000, output: 25000 },
  { month: "Feb", input: 18000, output: 30000 },
  { month: "Mar", input: 12000, output: 22000 }
];

const taxBreakdown = [
  { name: "CGST", value: 12500 },
  { name: "SGST", value: 12500 },
  { name: "IGST", value: 25000 }
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28"];

export default function GSTFilingPage() {
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<TaskRecommendation[]>([]);
  const [activeTab, setActiveTab] = useState("filing");

  const handleFileUpload = (files: File[]) => {
    console.log("Files uploaded:", files);
    setUploadedFiles(files.map(f => f.name));
  };

  const handleAcceptRecommendation = (recommendation: TaskRecommendation) => {
    console.log("Accepted recommendation:", recommendation);
    // TODO: Implement recommendation action
  };

  // Fetch recommendations whenever context changes
  useEffect(() => {
    const fetchRecommendations = async () => {
      const newRecommendations = await mockRecommendationService.getRecommendations({
        agentType: 'gst',
        currentTask: activeTab,
        uploadedFiles
      });
      setRecommendations(newRecommendations);
    };

    fetchRecommendations();
  }, [activeTab, uploadedFiles]);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">GST Filing Assistant</h1>

      {/* Recommendations Section */}
      {recommendations.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Recommended Actions</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {recommendations.map((recommendation) => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                onAccept={handleAcceptRecommendation}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Upload GST Documents</h2>
        <FileUpload 
          accept=".xlsx,.csv,.pdf"
          multiple
          onFilesSelected={handleFileUpload}
          className="max-w-2xl"
        />
      </div>

      <Tabs defaultValue="filing" className="mb-6" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="filing">GST Filing</TabsTrigger>
          <TabsTrigger value="reconciliation">Reconciliation</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="filing">
          <div className="grid gap-6 md:grid-cols-2">
            <AgentCard
              title="GST Filing Validation"
              description="Validate your GST filing details and get instant feedback"
              agentType="gst"
              onAnalyze={() => mockAgentService.gstAgent({
                quarter: "2024-Q1",
                transactions: [
                  { date: "2024-01-15", amount: 50000, type: "input", category: "raw_materials" },
                  { date: "2024-02-01", amount: 75000, type: "output", category: "finished_goods" },
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Monthly GST Summary</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyGST}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="input" fill="#8884d8" name="Input Tax" />
                      <Bar dataKey="output" fill="#82ca9d" name="Output Tax" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>

            <AgentCard
              title="Tax Breakdown Analysis"
              description="View detailed breakdown of tax components"
              agentType="gst"
              onAnalyze={() => mockAgentService.gstAgent({
                quarter: "2024-Q1",
                transactions: [
                  { date: "2024-01-15", amount: 25000, type: "input", category: "CGST" },
                  { date: "2024-01-15", amount: 25000, type: "input", category: "SGST" },
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Tax Component Distribution</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={taxBreakdown}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${name}: ₹${value}`}
                      >
                        {taxBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>
          </div>
        </TabsContent>

        <TabsContent value="reconciliation">
          <AgentCard
            title="Invoice Reconciliation"
            description="Match purchase and sales invoices with GST records"
            agentType="gst"
            onAnalyze={() => mockAgentService.gstAgent({
              quarter: "2024-Q1",
              transactions: [
                { date: "2024-01-15", amount: 50000, type: "input", category: "invoices" },
                { date: "2024-02-01", amount: 75000, type: "output", category: "invoices" },
              ]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Upload purchase and sales invoices for automatic reconciliation
                with GST portal data.
              </p>
            </Card>
          </AgentCard>
        </TabsContent>

        <TabsContent value="analysis">
          <AgentCard
            title="Tax Credit Analysis"
            description="Analyze input tax credits and optimize utilization"
            agentType="gst"
            onAnalyze={() => mockAgentService.gstAgent({
              quarter: "2024-Q1",
              transactions: [
                { date: "2024-01-15", amount: 25000, type: "credit", category: "utilized" },
                { date: "2024-02-01", amount: 15000, type: "credit", category: "pending" },
              ]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Available Credit: ₹40,000
                <br />
                Utilized: ₹25,000
                <br />
                Pending: ₹15,000
              </p>
            </Card>
          </AgentCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}