import { AgentCard } from "@/components/agents/AgentCard";
import { mockAgentService } from "@/lib/mockAgentService";
import { mockRecommendationService, TaskRecommendation } from "@/lib/mockRecommendationService";
import { RecommendationCard } from "@/components/agents/RecommendationCard";
import { Card } from "@/components/ui/card";
import { FileUpload } from "@/components/ui/file-upload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from "recharts";

// Sample data for charts
const riskData = [
  { category: "Financial", score: 0.2 },
  { category: "Operational", score: 0.4 },
  { category: "Compliance", score: 0.3 },
  { category: "Strategic", score: 0.6 },
];

const trendData = [
  { month: "Jan", actual: 150, predicted: 145 },
  { month: "Feb", actual: 170, predicted: 165 },
  { month: "Mar", actual: 160, predicted: 170 },
  { month: "Apr", actual: 180, predicted: 175 },
];

export default function AuditPage() {
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<TaskRecommendation[]>([]);
  const [activeTab, setActiveTab] = useState("financial");

  const handleFileUpload = (files: File[]) => {
    console.log("Files uploaded:", files);
    setUploadedFiles(files.map(f => f.name));
  };

  const handleAcceptRecommendation = (recommendation: TaskRecommendation) => {
    console.log("Accepted recommendation:", recommendation);
    // TODO: Implement recommendation action
  };

  // Fetch recommendations whenever context changes
  useEffect(() => {
    const fetchRecommendations = async () => {
      const newRecommendations = await mockRecommendationService.getRecommendations({
        agentType: 'audit',
        currentTask: activeTab,
        uploadedFiles
      });
      setRecommendations(newRecommendations);
    };

    fetchRecommendations();
  }, [activeTab, uploadedFiles]);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Audit Analysis</h1>

      {/* Recommendations Section */}
      {recommendations.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Recommended Actions</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {recommendations.map((recommendation) => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                onAccept={handleAcceptRecommendation}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Upload Documents for Analysis</h2>
        <FileUpload 
          accept=".pdf,.xlsx,.csv"
          multiple
          onFilesSelected={handleFileUpload}
          className="max-w-2xl"
        />
      </div>

      <Tabs defaultValue="financial" className="mb-6" value={activeTab} onChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="financial">Financial Analysis</TabsTrigger>
          <TabsTrigger value="compliance">Compliance Check</TabsTrigger>
          <TabsTrigger value="risk">Risk Assessment</TabsTrigger>
        </TabsList>

        <TabsContent value="financial">
          <div className="grid gap-6 md:grid-cols-2">
            <AgentCard
              title="Financial Statement Analysis"
              description="Analyze financial statements for discrepancies and insights"
              onAnalyze={() => mockAgentService.auditAgent({
                period: "2024-Q1",
                statements: [
                  {
                    type: "income",
                    data: {
                      revenue: 500000,
                      expenses: 350000,
                      profit: 150000
                    }
                  },
                  {
                    type: "balance",
                    data: {
                      assets: 1000000,
                      liabilities: 400000,
                      equity: 600000
                    }
                  }
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Revenue Trend Analysis</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual" />
                      <Line type="monotone" dataKey="predicted" stroke="#82ca9d" name="Predicted" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>

            <AgentCard
              title="Key Ratios Analysis"
              description="Calculate and analyze key financial ratios"
              onAnalyze={() => mockAgentService.auditAgent({
                period: "2024-Q1",
                statements: [{
                  type: "ratios",
                  data: {
                    currentRatio: 2.5,
                    quickRatio: 1.8,
                    debtToEquity: 0.67
                  }
                }]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <p className="text-sm text-muted-foreground">
                  Current Ratio: 2.5
                  <br />
                  Quick Ratio: 1.8
                  <br />
                  Debt to Equity: 0.67
                </p>
              </Card>
            </AgentCard>
          </div>
        </TabsContent>

        <TabsContent value="compliance">
          <AgentCard
            title="Regulatory Compliance Check"
            description="Verify compliance with financial regulations and standards"
            onAnalyze={() => mockAgentService.auditAgent({
              period: "2024-Q1",
              statements: [{
                type: "compliance",
                data: {
                  regulatoryFramework: "IFRS",
                  checkpoints: ["Revenue Recognition", "Asset Classification"]
                }
              }]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Compliance framework: IFRS
                <br />
                Key areas: Revenue Recognition, Asset Classification
              </p>
            </Card>
          </AgentCard>
        </TabsContent>

        <TabsContent value="risk">
          <AgentCard
            title="Risk Assessment"
            description="Evaluate potential risks and their impact"
            onAnalyze={() => mockAgentService.auditAgent({
              period: "2024-Q1",
              statements: [{
                type: "risk",
                data: {
                  riskFactors: ["Market", "Credit", "Operational"]
                }
              }]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <h3 className="font-medium mb-2">Risk Score by Category</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={riskData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="score" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </AgentCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}