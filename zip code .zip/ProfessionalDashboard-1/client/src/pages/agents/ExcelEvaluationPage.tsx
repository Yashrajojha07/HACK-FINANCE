import { AgentCard } from "@/components/agents/AgentCard";
import { mockAgentService } from "@/lib/mockAgentService";
import { mockRecommendationService, TaskRecommendation } from "@/lib/mockRecommendationService";
import { RecommendationCard } from "@/components/agents/RecommendationCard";
import { Card } from "@/components/ui/card";
import { FileUpload } from "@/components/ui/file-upload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

// Sample data for visualizations
const errorDistribution = [
  { name: "Formula Errors", value: 15 },
  { name: "Data Type Mismatches", value: 8 },
  { name: "Missing Values", value: 12 },
  { name: "Inconsistent Formats", value: 5 }
];

const sheetComplexity = [
  { sheet: "Sheet1", complexity: 75 },
  { sheet: "Sheet2", complexity: 45 },
  { sheet: "Sheet3", complexity: 90 },
  { sheet: "Sheet4", complexity: 30 }
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

export default function ExcelEvaluationPage() {
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<TaskRecommendation[]>([]);
  const [activeTab, setActiveTab] = useState("validation");

  const handleFileUpload = (files: File[]) => {
    console.log("Files uploaded:", files);
    setUploadedFiles(files.map(f => f.name));
  };

  const handleAcceptRecommendation = (recommendation: TaskRecommendation) => {
    console.log("Accepted recommendation:", recommendation);
    // TODO: Implement recommendation action
  };

  // Fetch recommendations whenever context changes
  useEffect(() => {
    const fetchRecommendations = async () => {
      const newRecommendations = await mockRecommendationService.getRecommendations({
        agentType: 'excel',
        currentTask: activeTab,
        uploadedFiles
      });
      setRecommendations(newRecommendations);
    };

    fetchRecommendations();
  }, [activeTab, uploadedFiles]);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Excel Evaluation Assistant</h1>

      {/* Recommendations Section */}
      {recommendations.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Recommended Actions</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {recommendations.map((recommendation) => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                onAccept={handleAcceptRecommendation}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Upload Excel Files</h2>
        <FileUpload 
          accept=".xlsx,.xls,.csv"
          multiple
          onFilesSelected={handleFileUpload}
          className="max-w-2xl"
        />
      </div>

      <Tabs defaultValue="validation" className="mb-6" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="validation">Data Validation</TabsTrigger>
          <TabsTrigger value="complexity">Complexity Analysis</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
        </TabsList>

        <TabsContent value="validation">
          <div className="grid gap-6 md:grid-cols-2">
            <AgentCard
              title="Excel Data Validation"
              description="Validate Excel data for errors and inconsistencies"
              onAnalyze={() => mockAgentService.excelAgent({
                fileType: "xlsx",
                validation: {
                  sheets: ["Sheet1", "Sheet2"],
                  rules: ["data_type", "formula", "missing_values"]
                }
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Error Distribution</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={errorDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {errorDistribution.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={COLORS[index % COLORS.length]} 
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>

            <AgentCard
              title="Formula Validation"
              description="Check Excel formulas for errors and consistency"
              onAnalyze={() => mockAgentService.excelAgent({
                fileType: "xlsx",
                analysis: {
                  type: "formula",
                  depth: "detailed"
                }
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Sheet Complexity Score</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sheetComplexity}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="sheet" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar 
                        dataKey="complexity" 
                        fill="#8884d8" 
                        name="Complexity Score" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>
          </div>
        </TabsContent>

        <TabsContent value="complexity">
          <AgentCard
            title="Workbook Complexity Analysis"
            description="Analyze Excel workbook structure and complexity"
            onAnalyze={() => mockAgentService.excelAgent({
              fileType: "xlsx",
              analysis: {
                type: "complexity",
                metrics: ["formula_depth", "data_relationships", "sheet_coupling"]
              }
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Analyze workbook complexity based on:
                <br />- Formula complexity
                <br />- Data relationships
                <br />- Sheet dependencies
                <br />- Named ranges usage
              </p>
            </Card>
          </AgentCard>
        </TabsContent>

        <TabsContent value="optimization">
          <AgentCard
            title="Performance Optimization"
            description="Identify and fix performance issues in Excel workbooks"
            onAnalyze={() => mockAgentService.excelAgent({
              fileType: "xlsx",
              optimization: {
                target: "performance",
                areas: ["formulas", "data_structure", "naming"]
              }
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Optimization Recommendations:
                <br />- Simplify complex formulas
                <br />- Optimize data structure
                <br />- Improve naming conventions
                <br />- Reduce calculation chains
              </p>
            </Card>
          </AgentCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}
