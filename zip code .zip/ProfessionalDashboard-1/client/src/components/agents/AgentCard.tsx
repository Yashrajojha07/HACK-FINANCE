import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LoaderCircle } from "lucide-react";
import { AgentResponse } from "@shared/types/agents";
import { useState } from "react";
import { geminiService } from "@/lib/geminiService";

interface AgentCardProps {
  title: string;
  description: string;
  onAnalyze: () => Promise<any>;
  children?: React.ReactNode;
  agentType: string;
}

export function AgentCard({ title, description, onAnalyze, children, agentType }: AgentCardProps) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AgentResponse | null>(null);

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      const data = await onAnalyze();
      const response = await geminiService.analyzeWithAgent({
        agentType,
        data
      });
      setResult(response);
    } catch (error) {
      console.error('Agent analysis failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {children}
        {result && (
          <div className="mt-4 p-4 bg-secondary rounded-lg">
            <h4 className="font-medium mb-2">Analysis Result:</h4>
            <pre className="whitespace-pre-wrap text-sm">
              {JSON.stringify(result.data, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleAnalyze} 
          disabled={loading}
          className="w-full"
        >
          {loading && <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />}
          {loading ? 'Analyzing...' : 'Start Analysis'}
        </Button>
      </CardFooter>
    </Card>
  );
}