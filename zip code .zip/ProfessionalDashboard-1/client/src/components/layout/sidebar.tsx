import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useState } from "react";
import {
  LayoutDashboard,
  Users,
  FileSpreadsheet,
  LineChart,
  ShieldCheck,
  Receipt,
  MessageSquare,
  Settings,
  HelpCircle,
  Bot,
  Database,
  FileText,
  BarChart3,
  Package,
  CreditCard,
  FolderKanban,
  ChevronRight,
  Calendar
} from "lucide-react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  {
    name: "AI Agents",
    icon: Bot,
    children: [
      { name: "Audit Agents", href: "/agents/audit", icon: Users },
      { name: "GST Filing", href: "/agents/gst", icon: Receipt },
      { name: "Fraud Detection", href: "/agents/fraud", icon: ShieldCheck },
      { name: "Trade Analytics", href: "/agents/trade", icon: LineChart },
      { name: "Excel Evaluation", href: "/agents/excel", icon: FileSpreadsheet },
    ]
  },
  {
    name: "Task Management",
    icon: Calendar,
    children: [
      { name: "Task Scheduler", href: "/scheduler", icon: Calendar },
    ]
  },
  {
    name: "Data Management",
    icon: Database,
    children: [
      { name: "Financial Reports", href: "/reports", icon: FileText },
      { name: "Customer Data", href: "/data/customers", icon: Users },
      { name: "Analytics", href: "/data/analytics", icon: BarChart3 },
      { name: "Inventory", href: "/data/inventory", icon: Package },
      { name: "Transactions", href: "/data/transactions", icon: CreditCard },
      { name: "Documents", href: "/data/documents", icon: FolderKanban },
    ]
  },
  { name: "Agent Chat", href: "/chat", icon: MessageSquare },
  { name: "Settings", href: "/settings", icon: Settings },
  { name: "Help", href: "/help", icon: HelpCircle },
];

export function Sidebar() {
  const [location] = useLocation();
  const [openSections, setOpenSections] = useState<string[]>(["AI Agents", "Task Management", "Data Management"]);

  const toggleSection = (sectionName: string) => {
    setOpenSections(prev =>
      prev.includes(sectionName)
        ? prev.filter(name => name !== sectionName)
        : [...prev, sectionName]
    );
  };

  return (
    <div className="fixed inset-y-0 left-0 w-64 bg-white/50 backdrop-blur-sm border-r border-border">
      <div className="flex h-16 items-center px-6">
        <h1 className="text-xl font-semibold text-sidebar-foreground">AI Finance</h1>
      </div>
      <nav className="space-y-1 px-3">
        {navigation.map((item) => {
          if (item.children) {
            const isOpen = openSections.includes(item.name);
            return (
              <Collapsible
                key={item.name}
                open={isOpen}
                onOpenChange={() => toggleSection(item.name)}
                className="space-y-1"
              >
                <CollapsibleTrigger className="flex w-full items-center px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md">
                  <item.icon className="mr-3 h-5 w-5" aria-hidden="true" />
                  {item.name}
                  <ChevronRight className={cn(
                    "ml-auto h-5 w-5 transition-transform",
                    isOpen && "transform rotate-90"
                  )} />
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-1 pl-11">
                  {item.children.map((child) => {
                    const isActive = location === child.href;
                    return (
                      <Link key={child.name} href={child.href}>
                        <a
                          className={cn(
                            "flex items-center px-3 py-2 text-sm font-medium rounded-md",
                            isActive
                              ? "bg-primary text-primary-foreground"
                              : "text-gray-700 hover:bg-gray-100"
                          )}
                        >
                          <child.icon className="mr-3 h-4 w-4" aria-hidden="true" />
                          {child.name}
                        </a>
                      </Link>
                    );
                  })}
                </CollapsibleContent>
              </Collapsible>
            );
          }

          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <a
                className={cn(
                  "flex items-center px-3 py-2 text-sm font-medium rounded-md",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-gray-700 hover:bg-gray-100"
                )}
              >
                <item.icon className="mr-3 h-5 w-5" aria-hidden="true" />
                {item.name}
              </a>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}