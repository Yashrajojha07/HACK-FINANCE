import { AgentResponse } from '@shared/types/agents';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export interface TaskRecommendation {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  agentType: 'audit' | 'gst' | 'trade';
  suggestedFiles?: string[];
}

export const mockRecommendationService = {
  async getRecommendations(context: {
    agentType: string;
    currentTask?: string;
    uploadedFiles?: string[];
  }): Promise<TaskRecommendation[]> {
    await delay(1000);

    // Mock recommendations based on agent type
    const recommendations: Record<string, TaskRecommendation[]> = {
      audit: [
        {
          id: '1',
          title: 'Review Financial Ratios',
          description: 'Analyze key financial ratios for potential anomalies',
          priority: 'high',
          agentType: 'audit',
          suggestedFiles: ['balance_sheet.xlsx', 'income_statement.xlsx']
        },
        {
          id: '2',
          title: 'Compliance Check',
          description: 'Verify compliance with latest regulatory requirements',
          priority: 'medium',
          agentType: 'audit',
          suggestedFiles: ['compliance_checklist.pdf']
        }
      ],
      gst: [
        {
          id: '3',
          title: 'Reconcile Input Credits',
          description: 'Match input tax credits with purchase invoices',
          priority: 'high',
          agentType: 'gst',
          suggestedFiles: ['purchase_invoices.xlsx']
        },
        {
          id: '4',
          title: 'Review Tax Categories',
          description: 'Verify correct tax category application',
          priority: 'medium',
          agentType: 'gst',
          suggestedFiles: ['tax_classification.xlsx']
        }
      ],
      trade: [
        {
          id: '5',
          title: 'Volatility Analysis',
          description: 'Analyze market volatility patterns',
          priority: 'high',
          agentType: 'trade',
          suggestedFiles: ['market_data.csv']
        },
        {
          id: '6',
          title: 'Sector Performance Review',
          description: 'Review sector-wise performance trends',
          priority: 'medium',
          agentType: 'trade',
          suggestedFiles: ['sector_data.xlsx']
        }
      ]
    };

    return recommendations[context.agentType] || [];
  }
};
