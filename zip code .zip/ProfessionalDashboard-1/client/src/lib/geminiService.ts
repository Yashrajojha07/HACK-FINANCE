import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize the API with error handling
let genAI: GoogleGenerativeAI;
try {
  genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);
} catch (error) {
  console.error('Failed to initialize Gemini API:', error);
  throw new Error('Failed to initialize AI service');
}

type AgentContext = {
  agentType: string;
  data: any;
};

export const geminiService = {
  async generateChatResponse(message: string): Promise<string> {
    try {
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });

      const prompt = `You are an AI Finance Assistant helping with tasks like GST filing, 
      audit analysis, fraud detection, and trade analytics. 

      User message: ${message}

      Provide a helpful, professional response focusing on finance and accounting topics.
      Keep your response concise and focused on the specific query.`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Error generating chat response:', error);
      throw new Error('Failed to generate response');
    }
  },

  async analyzeWithAgent({ agentType, data }: AgentContext): Promise<any> {
    try {
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });

      const prompts: Record<string, string> = {
        audit: `Analyze the following financial data and provide insights:
          ${JSON.stringify(data, null, 2)}

          Provide analysis focusing on:
          1. Key financial ratios
          2. Risk indicators
          3. Compliance issues
          4. Recommendations`,

        gst: `Review the following GST filing data:
          ${JSON.stringify(data, null, 2)}

          Analyze for:
          1. Compliance with GST rules
          2. Input/output tax reconciliation
          3. Filing accuracy
          4. Potential issues`,

        trade: `Analyze the following trading data:
          ${JSON.stringify(data, null, 2)}

          Provide insights on:
          1. Market patterns
          2. Risk assessment
          3. Trading opportunities
          4. Performance metrics`,

        fraud: `Analyze these transactions for potential fraud:
          ${JSON.stringify(data, null, 2)}

          Focus on:
          1. Anomaly detection
          2. Risk scoring
          3. Pattern recognition
          4. Security recommendations`,

        excel: `Evaluate the following Excel workbook structure:
          ${JSON.stringify(data, null, 2)}

          Analyze for:
          1. Formula complexity
          2. Data validation
          3. Optimization opportunities
          4. Best practices`
      };

      const prompt = prompts[agentType];
      if (!prompt) {
        throw new Error(`Invalid agent type: ${agentType}`);
      }

      const result = await model.generateContent(prompt);
      const response = await result.response;

      try {
        // Try to parse the response as structured data
        const parsed = JSON.parse(response.text());
        return {
          message: `${agentType} analysis completed`,
          timestamp: new Date().toISOString(),
          status: 'success',
          data: parsed
        };
      } catch {
        // If parsing fails, return a formatted response
        return {
          message: `${agentType} analysis completed`,
          timestamp: new Date().toISOString(),
          status: 'success',
          data: {
            analysis: response.text(),
            recommendations: []
          }
        };
      }
    } catch (error) {
      console.error('Error in agent analysis:', error);
      throw new Error('Failed to analyze with agent');
    }
  }
};