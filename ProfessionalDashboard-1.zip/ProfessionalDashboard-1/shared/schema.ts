import { pgTable, text, serial, integer, timestamp, decimal, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  value: decimal("value", { precision: 10, scale: 2 }).notNull(),
  change: decimal("change", { precision: 5, scale: 2 }).notNull(),
  type: text("type").notNull(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  value: decimal("value", { precision: 10, scale: 2 }).notNull(),
  timestamp: timestamp("timestamp").notNull(),
});

export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // audit, gst, fraud_detection, trade_analytics, excel_evaluation
  description: text("description").notNull(),
  capabilities: text("capabilities").array().notNull(),
  status: text("status").notNull().default('available'), // available, busy, offline
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  agent_id: integer("agent_id").references(() => agents.id).notNull(),
  type: text("type").notNull(),
  status: text("status").notNull().default('pending'), // pending, in_progress, completed, failed
  input_data: jsonb("input_data").notNull(),
  priority: text("priority").notNull().default('normal'), // low, normal, high
  created_at: timestamp("created_at").defaultNow().notNull(),
  completed_at: timestamp("completed_at"),
});

export const taskResults = pgTable("task_results", {
  id: serial("id").primaryKey(),
  task_id: integer("task_id").references(() => tasks.id).notNull(),
  result_data: jsonb("result_data").notNull(),
  success: boolean("success").notNull(),
  error_message: text("error_message"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertMetricSchema = createInsertSchema(metrics).pick({
  title: true,
  value: true,
  change: true,
  type: true,
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  value: true,
  timestamp: true,
});

export const insertAgentSchema = createInsertSchema(agents).pick({
  name: true,
  type: true,
  description: true,
  capabilities: true,
  status: true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  agent_id: true,
  type: true,
  input_data: true,
  priority: true,
});

export const insertTaskResultSchema = createInsertSchema(taskResults).pick({
  task_id: true,
  result_data: true,
  success: true,
  error_message: true,
});

// Types
export type InsertMetric = z.infer<typeof insertMetricSchema>;
export type Metric = typeof metrics.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Agent = typeof agents.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertTaskResult = z.infer<typeof insertTaskResultSchema>;
export type TaskResult = typeof taskResults.$inferSelect;