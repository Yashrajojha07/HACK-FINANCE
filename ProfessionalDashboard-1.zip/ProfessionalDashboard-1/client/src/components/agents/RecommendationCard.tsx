import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileUp, AlertCircle } from "lucide-react";
import { TaskRecommendation } from "@/lib/mockRecommendationService";

interface RecommendationCardProps {
  recommendation: TaskRecommendation;
  onAccept: (recommendation: TaskRecommendation) => void;
}

export function RecommendationCard({ recommendation, onAccept }: RecommendationCardProps) {
  const priorityColors = {
    high: "text-red-500",
    medium: "text-yellow-500",
    low: "text-green-500"
  };

  return (
    <Card className="w-full hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{recommendation.title}</CardTitle>
          <span className={`text-sm font-medium ${priorityColors[recommendation.priority]}`}>
            {recommendation.priority.charAt(0).toUpperCase() + recommendation.priority.slice(1)} Priority
          </span>
        </div>
        <CardDescription>{recommendation.description}</CardDescription>
      </CardHeader>
      <CardContent>
        {recommendation.suggestedFiles && recommendation.suggestedFiles.length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-medium mb-2">Suggested Files:</h4>
            <ul className="text-sm text-muted-foreground">
              {recommendation.suggestedFiles.map((file, index) => (
                <li key={index} className="flex items-center gap-2">
                  <FileUp className="h-4 w-4" />
                  {file}
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="flex justify-end gap-2">
          <Button 
            variant="default"
            onClick={() => onAccept(recommendation)}
          >
            Accept Recommendation
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
