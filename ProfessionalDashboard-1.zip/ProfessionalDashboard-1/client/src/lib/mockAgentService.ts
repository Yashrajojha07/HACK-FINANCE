import { AgentResponse } from '@shared/types/agents';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockAgentService = {
  async auditAgent(data: any): Promise<AgentResponse> {
    await delay(1500); // Simulate API call
    return {
      message: "Audit analysis completed successfully",
      timestamp: new Date().toISOString(),
      status: 'success',
      data: {
        riskScore: 0.2,
        findings: [
          { severity: 'low', message: 'Minor discrepancy in travel expenses' },
          { severity: 'info', message: 'Cash flow trends are healthy' }
        ],
        recommendations: [
          'Consider reviewing travel expense policies',
          'Current financial health indicators are positive'
        ]
      }
    };
  },

  async gstAgent(data: any): Promise<AgentResponse> {
    await delay(1000);
    return {
      message: "GST filing validation completed",
      timestamp: new Date().toISOString(),
      status: 'success',
      data: {
        isValid: true,
        totalTax: 25000,
        breakdowns: {
          inputTax: 15000,
          outputTax: 40000,
        },
        suggestions: [
          'All required fields are properly filled',
          'Supporting documents are complete'
        ]
      }
    };
  },

  async tradeAgent(data: any): Promise<AgentResponse> {
    await delay(2000);
    return {
      message: "Trade pattern analysis completed",
      timestamp: new Date().toISOString(),
      status: 'success',
      data: {
        patterns: [
          {
            type: 'trend',
            description: 'Bullish pattern detected in technology sector',
            confidence: 0.85
          },
          {
            type: 'volatility',
            description: 'Increased market volatility expected',
            confidence: 0.75
          }
        ],
        recommendations: [
          'Consider reducing exposure to volatile assets',
          'Opportunity for sector rotation identified'
        ]
      }
    };
  },

  async fraudAgent(data: any): Promise<AgentResponse> {
    await delay(1800);
    return {
      message: "Fraud detection analysis completed",
      timestamp: new Date().toISOString(),
      status: 'success',
      data: {
        overallRiskScore: 0.65,
        anomalies: [
          {
            type: 'transaction',
            description: 'Unusual transaction pattern detected',
            confidence: 0.85,
            severity: 'high'
          },
          {
            type: 'behavior',
            description: 'Suspicious login activity',
            confidence: 0.70,
            severity: 'medium'
          }
        ],
        recommendations: [
          'Review high-risk transactions',
          'Update security protocols'
        ]
      }
    };
  },

  async excelAgent(data: any): Promise<AgentResponse> {
    await delay(1200);
    return {
      message: "Excel workbook analysis completed",
      timestamp: new Date().toISOString(),
      status: 'success',
      data: {
        worksheetCount: 3,
        findings: [
          {
            type: 'formula',
            description: 'Complex nested formulas detected',
            recommendation: 'Consider simplifying formulas for better maintenance'
          },
          {
            type: 'data',
            description: 'Missing values in critical columns',
            recommendation: 'Fill in required data or mark as intentionally empty'
          }
        ],
        optimizationSuggestions: [
          'Reduce volatile formula usage',
          'Consolidate similar worksheets'
        ]
      }
    };
  }
};