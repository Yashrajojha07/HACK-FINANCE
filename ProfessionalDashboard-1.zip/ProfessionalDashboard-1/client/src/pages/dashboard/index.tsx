import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Header } from "@/components/layout/header";
import { StatsGrid } from "./components/stats-grid";
import { AgentGrid } from "./components/agent-grid";
import { AgentChat } from "./components/agent-chat";

export default function Dashboard() {
  const { data: metrics, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ["/api/metrics"],
  });

  const { data: agents, isLoading: isLoadingAgents } = useQuery({
    queryKey: ["/api/agents"],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-600 mt-1">
            Monitor your AI agents and financial metrics
          </p>
        </div>

        <StatsGrid metrics={metrics} isLoading={isLoadingMetrics} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="p-6">
              <h2 className="text-lg font-medium mb-4">Active AI Agents</h2>
              <AgentGrid agents={agents} isLoading={isLoadingAgents} />
            </Card>
          </div>
          <div>
            <AgentChat />
          </div>
        </div>
      </main>
    </div>
  );
}