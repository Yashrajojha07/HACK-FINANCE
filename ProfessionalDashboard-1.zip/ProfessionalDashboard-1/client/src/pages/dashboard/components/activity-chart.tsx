import { Line, LineChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import type { Activity } from "@shared/schema";

interface ActivityChartProps {
  data?: Activity[];
  isLoading: boolean;
}

export function ActivityChart({ data, isLoading }: ActivityChartProps) {
  if (isLoading) {
    return <Skeleton className="h-[400px]" />;
  }

  return (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={data}>
        <XAxis 
          dataKey="timestamp" 
          tickFormatter={(value) => format(new Date(value), 'MMM d')}
        />
        <YAxis />
        <Tooltip
          labelFormatter={(value) => format(new Date(value), 'MMM d, yyyy')}
        />
        <Line
          type="monotone"
          dataKey="value"
          stroke="hsl(var(--primary))"
          strokeWidth={2}
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
