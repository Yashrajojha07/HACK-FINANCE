import { Card } from "@/components/ui/card";
import { ArrowUpIcon, ArrowDownIcon } from "lucide-react";
import type { Metric } from "@shared/schema";

interface MetricCardProps {
  metric: Metric;
}

export function MetricCard({ metric }: MetricCardProps) {
  const isPositive = parseFloat(metric.change) >= 0;
  const formattedValue = (() => {
    const value = parseFloat(metric.value);
    switch (metric.type) {
      case 'currency':
        return new Intl.NumberFormat('en-US', { 
          style: 'currency', 
          currency: 'USD' 
        }).format(value);
      case 'percentage':
        return `${value.toFixed(1)}%`;
      case 'time':
        return `${value.toFixed(1)}min`;
      default:
        return value.toLocaleString();
    }
  })();

  return (
    <Card className="p-6">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
          <p className="text-2xl font-semibold mt-2">{formattedValue}</p>
        </div>
        <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          {isPositive ? <ArrowUpIcon className="w-4 h-4" /> : <ArrowDownIcon className="w-4 h-4" />}
          <span className="ml-1 text-sm font-medium">
            {Math.abs(parseFloat(metric.change))}%
          </span>
        </div>
      </div>
    </Card>
  );
}