import { AgentCard } from "@/components/agents/AgentCard";
import { mockAgentService } from "@/lib/mockAgentService";
import { mockRecommendationService, TaskRecommendation } from "@/lib/mockRecommendationService";
import { RecommendationCard } from "@/components/agents/RecommendationCard";
import { Card } from "@/components/ui/card";
import { FileUpload } from "@/components/ui/file-upload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  ZAxis
} from "recharts";

// Sample data for visualizations
const anomalyScores = [
  { timestamp: "2024-01-01", score: 0.2 },
  { timestamp: "2024-01-02", score: 0.3 },
  { timestamp: "2024-01-03", score: 0.8 },
  { timestamp: "2024-01-04", score: 0.4 },
  { timestamp: "2024-01-05", score: 0.9 }
];

const transactionPatterns = [
  { amount: 1000, frequency: 5, risk: 0.2 },
  { amount: 5000, frequency: 3, risk: 0.4 },
  { amount: 10000, frequency: 1, risk: 0.8 },
  { amount: 2000, frequency: 8, risk: 0.3 },
  { amount: 8000, frequency: 2, risk: 0.6 }
];

export default function FraudDetectionPage() {
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<TaskRecommendation[]>([]);
  const [activeTab, setActiveTab] = useState("anomaly");

  const handleFileUpload = (files: File[]) => {
    console.log("Files uploaded:", files);
    setUploadedFiles(files.map(f => f.name));
  };

  const handleAcceptRecommendation = (recommendation: TaskRecommendation) => {
    console.log("Accepted recommendation:", recommendation);
    // TODO: Implement recommendation action
  };

  // Fetch recommendations whenever context changes
  useEffect(() => {
    const fetchRecommendations = async () => {
      const newRecommendations = await mockRecommendationService.getRecommendations({
        agentType: 'fraud',
        currentTask: activeTab,
        uploadedFiles
      });
      setRecommendations(newRecommendations);
    };

    fetchRecommendations();
  }, [activeTab, uploadedFiles]);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Fraud Detection Assistant</h1>

      {/* Recommendations Section */}
      {recommendations.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Recommended Actions</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {recommendations.map((recommendation) => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                onAccept={handleAcceptRecommendation}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Upload Transaction Data</h2>
        <FileUpload 
          accept=".csv,.xlsx,.json"
          multiple
          onFilesSelected={handleFileUpload}
          className="max-w-2xl"
        />
      </div>

      <Tabs defaultValue="anomaly" className="mb-6" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="anomaly">Anomaly Detection</TabsTrigger>
          <TabsTrigger value="patterns">Pattern Analysis</TabsTrigger>
          <TabsTrigger value="risk">Risk Assessment</TabsTrigger>
        </TabsList>

        <TabsContent value="anomaly">
          <div className="grid gap-6 md:grid-cols-2">
            <AgentCard
              title="Transaction Anomaly Detection"
              description="Detect unusual transaction patterns and potential fraud"
              onAnalyze={() => mockAgentService.fraudAgent({
                timeframe: "1W",
                transactions: [
                  { timestamp: "2024-02-01T10:00:00Z", amount: 5000, risk_score: 0.8 },
                  { timestamp: "2024-02-01T11:00:00Z", amount: 1000, risk_score: 0.2 }
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Anomaly Score Timeline</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={anomalyScores}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="timestamp" />
                      <YAxis domain={[0, 1]} />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#ff4d4f" 
                        name="Risk Score" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>

            <AgentCard
              title="Transaction Pattern Analysis"
              description="Analyze transaction patterns to identify suspicious behavior"
              onAnalyze={() => mockAgentService.fraudAgent({
                timeframe: "1W",
                transactions: [
                  { amount: 5000, frequency: 3, pattern_score: 0.6 },
                  { amount: 1000, frequency: 8, pattern_score: 0.2 }
                ]
              })}
            >
              <Card className="bg-secondary p-4 mb-4">
                <h3 className="font-medium mb-2">Transaction Patterns</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="amount" 
                        name="Transaction Amount" 
                        unit="₹" 
                      />
                      <YAxis 
                        dataKey="frequency" 
                        name="Frequency" 
                      />
                      <ZAxis 
                        dataKey="risk" 
                        range={[50, 400]} 
                        name="Risk Score" 
                      />
                      <Tooltip 
                        cursor={{ strokeDasharray: '3 3' }} 
                      />
                      <Scatter 
                        name="Transactions" 
                        data={transactionPatterns} 
                        fill="#ff4d4f" 
                      />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </AgentCard>
          </div>
        </TabsContent>

        <TabsContent value="patterns">
          <AgentCard
            title="Behavioral Pattern Analysis"
            description="Analyze user behavior patterns to detect suspicious activities"
            onAnalyze={() => mockAgentService.fraudAgent({
              timeframe: "1W",
              patterns: [
                { type: "location", frequency: 10, risk_score: 0.3 },
                { type: "timing", frequency: 5, risk_score: 0.7 }
              ]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Upload historical transaction data to analyze behavioral patterns
                and identify potential fraudulent activities based on:
                <br />- Location patterns
                <br />- Timing patterns
                <br />- Amount patterns
                <br />- Device patterns
              </p>
            </Card>
          </AgentCard>
        </TabsContent>

        <TabsContent value="risk">
          <AgentCard
            title="Risk Assessment"
            description="Comprehensive risk assessment of transactions and patterns"
            onAnalyze={() => mockAgentService.fraudAgent({
              timeframe: "1W",
              risk_factors: [
                { category: "location", score: 0.8 },
                { category: "amount", score: 0.4 },
                { category: "frequency", score: 0.6 }
              ]
            })}
          >
            <Card className="bg-secondary p-4 mb-4">
              <p className="text-sm text-muted-foreground">
                Overall Risk Score: High (0.8)
                <br />
                Risk Factors:
                <br />- Unusual location
                <br />- High transaction frequency
                <br />- Irregular timing
              </p>
            </Card>
          </AgentCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}
