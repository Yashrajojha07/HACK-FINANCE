import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAgentSchema, insertTaskSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Existing routes
  app.get("/api/metrics", async (_req, res) => {
    const metrics = await storage.getMetrics();
    res.json(metrics);
  });

  app.get("/api/activities", async (_req, res) => {
    const activities = await storage.getActivities();
    res.json(activities);
  });

  // Agent routes
  app.get("/api/agents", async (_req, res) => {
    const agents = await storage.getAgents();
    res.json(agents);
  });

  app.post("/api/agents", async (req, res) => {
    try {
      const agentData = insertAgentSchema.parse(req.body);
      const agent = await storage.createAgent(agentData);
      res.status(201).json(agent);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid agent data", errors: error.errors });
      } else {
        throw error;
      }
    }
  });

  app.patch("/api/agents/:id/status", async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!status || typeof status !== "string") {
      return res.status(400).json({ message: "Status is required" });
    }

    const agent = await storage.updateAgentStatus(parseInt(id), status);
    if (!agent) {
      return res.status(404).json({ message: "Agent not found" });
    }

    res.json(agent);
  });

  // Task routes
  app.get("/api/tasks", async (_req, res) => {
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        throw error;
      }
    }
  });

  app.patch("/api/tasks/:id/status", async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!status || typeof status !== "string") {
      return res.status(400).json({ message: "Status is required" });
    }

    const task = await storage.updateTaskStatus(parseInt(id), status);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    res.json(task);
  });

  app.get("/api/tasks/:id/result", async (req, res) => {
    const { id } = req.params;
    const result = await storage.getTaskResult(parseInt(id));

    if (!result) {
      return res.status(404).json({ message: "Task result not found" });
    }

    res.json(result);
  });

  const httpServer = createServer(app);
  return httpServer;
}