import { metrics, activities, agents, tasks, taskResults } from "@shared/schema";
import type { 
  Metric, Activity, Agent, Task, TaskResult,
  InsertMetric, InsertActivity, InsertAgent, InsertTask, InsertTaskResult 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Metrics
  getMetrics(): Promise<Metric[]>;
  createMetric(metric: InsertMetric): Promise<Metric>;

  // Activities
  getActivities(): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Agents
  getAgents(): Promise<Agent[]>;
  getAgent(id: number): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgentStatus(id: number, status: string): Promise<Agent>;

  // Tasks
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskStatus(id: number, status: string): Promise<Task>;

  // Task Results
  getTaskResult(taskId: number): Promise<TaskResult | undefined>;
  createTaskResult(result: InsertTaskResult): Promise<TaskResult>;
}

export class DatabaseStorage implements IStorage {
  // Metrics
  async getMetrics(): Promise<Metric[]> {
    return await db.select().from(metrics);
  }

  async createMetric(metric: InsertMetric): Promise<Metric> {
    const [newMetric] = await db.insert(metrics).values(metric).returning();
    return newMetric;
  }

  // Activities
  async getActivities(): Promise<Activity[]> {
    return await db.select().from(activities).orderBy(activities.timestamp);
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  // Agents
  async getAgents(): Promise<Agent[]> {
    return await db.select().from(agents);
  }

  async getAgent(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }

  async createAgent(agent: InsertAgent): Promise<Agent> {
    const [newAgent] = await db.insert(agents).values(agent).returning();
    return newAgent;
  }

  async updateAgentStatus(id: number, status: string): Promise<Agent> {
    const [updatedAgent] = await db
      .update(agents)
      .set({ status })
      .where(eq(agents.id, id))
      .returning();
    return updatedAgent;
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .orderBy(desc(tasks.created_at));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTaskStatus(id: number, status: string): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ 
        status,
        completed_at: status === 'completed' ? new Date() : null 
      })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }

  // Task Results
  async getTaskResult(taskId: number): Promise<TaskResult | undefined> {
    const [result] = await db
      .select()
      .from(taskResults)
      .where(eq(taskResults.task_id, taskId));
    return result;
  }

  async createTaskResult(result: InsertTaskResult): Promise<TaskResult> {
    const [newResult] = await db
      .insert(taskResults)
      .values(result)
      .returning();
    return newResult;
  }
}

export const storage = new DatabaseStorage();